package Item;

public class Items {

    /*
    Create an Instance variables
      private double price
      private static double allUserPrice

     */

    /*
        Create a method name is ItemName
        Return type is void
        Parameter is String(myItem)

        NOTE : USE SWITCH STATEMENT

        if my item = Rose teddy bear
            add 30 to price variable

        if my item = Iphone max
            add 850.23 to price variable

         if my item = laptop mouse
            add 23.50 to price variable

         if my item = Monitor
            add 90.23 to price variable

          if my item = charger
            add 43.20 to price variable

         if my item = hdmi cable
            add 5.90 to price variable

         if my item = mug
            add 15.79 to price variable

     */

    /*
        Create a method name is colorPrice
        Return type is void
        Parameter is String(color)

        NOTE : USE SWITCH STATEMENT

           if color = Red
            add 10 to price variable

           if color = Blue
            add 6 to price variable

           if color = Black
            add 4 to price variable

           if color = White
            add 2 to price variable
     */



    /*
    Create a method name is customText
    return type is double
    parameters are  one boolean and one String

    if boolean true and String length is more then 10
        add 5 to price variable

    if boolean true and String length is more then or equal to 10
        add 3 to price variable

     */


    /*
        Create a method name is AddtoAllUserPrice
        return type is void
        no parameter

        add price to allUserPrice

     */


    /*
        Create a static method name is getAllUserPrice
        return type is double
        no parameter

        return the allUserPrice
     */

}
